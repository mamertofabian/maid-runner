"""Version information for maid-agents package."""

__version__ = "0.1.0"
