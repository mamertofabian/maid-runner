"""MAID Agents: Claude Code automation for Manifest-driven AI Development."""

from maid_agents.__version__ import __version__

__all__ = ["__version__"]
