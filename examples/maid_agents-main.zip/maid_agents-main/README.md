# MAID Agents

Claude Code automation agents for the MAID (Manifest-driven AI Development) methodology.

## Overview

MAID Agents is a Claude Code-based automation layer for the MAID methodology. It uses Claude Code's headless CLI mode to automate the four phases of MAID workflow:

1. **Phase 1: Goal Definition** - ManifestArchitect agent creates precise manifests
2. **Phase 2: Planning Loop** - TestDesigner agent generates behavioral tests
3. **Phase 3: Implementation** - Developer agent implements code to pass tests
4. **Phase 3.5: Refactoring** - Refactorer agent improves code quality

## Installation

```bash
# Install from source
uv pip install -e .

# Verify installation
ccmaid --version
```

## Prerequisites

- maid-runner package installed
- Claude Code CLI installed and authenticated
- Python 3.12+

## Usage

### Standard MAID Workflow (TDD)

```bash
# Run full MAID workflow
ccmaid run "Add user authentication to the API"

# Run specific phases
ccmaid plan "Add user authentication"  # Phase 1-2: Manifest + Tests
ccmaid implement manifests/task-042.manifest.json  # Phase 3: Implementation
ccmaid refactor manifests/task-042.manifest.json   # Phase 3.5: Refactoring
ccmaid refine manifests/task-042.manifest.json --goal "Improve test coverage"  # Phase 2 quality gate
```

### Reverse Workflow (Tests from Existing Code)

When working with existing code or after using `maid snapshot`:

```bash
# Step 1: Generate manifest from existing code
maid snapshot path/to/existing/code.py

# Step 2: Generate behavioral tests from implementation
ccmaid generate-test manifests/task-NNN-code.manifest.json -i path/to/existing/code.py

# Step 3: Validate the complete manifest
maid validate manifests/task-NNN-code.manifest.json
```

The `generate-test` command supports three modes:
- **Create new**: Generate tests from scratch when none exist
- **Enhance stub**: Fill in placeholder tests created by `maid snapshot`
- **Improve existing**: Enhance and complete existing tests

## Architecture

See `docs/architecture.md` for detailed architecture and design decisions.

## Development

This package dogfoods the MAID methodology - it was built using MAID itself!

All manifests are in `manifests/`, all behavioral tests in `tests/`.

## License

MIT License - See LICENSE file
