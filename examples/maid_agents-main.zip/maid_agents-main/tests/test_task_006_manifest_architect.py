"""
Behavioral tests for Task-006: ManifestArchitect Agent.

Tests the ManifestArchitect agent that creates MAID manifests from goals.
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from maid_agents.agents.manifest_architect import ManifestArchitect
from maid_agents.claude.cli_wrapper import ClaudeWrapper


def test_manifest_architect_instantiation():
    """Test ManifestArchitect can be instantiated with ClaudeWrapper."""
    claude = ClaudeWrapper(mock_mode=True)
    architect = ManifestArchitect(claude)

    assert architect is not None
    assert isinstance(architect, ManifestArchitect)
    assert architect.claude is not None


def test_create_manifest_method_signature():
    """Test create_manifest method exists with correct signature."""
    claude = ClaudeWrapper(mock_mode=True)
    architect = ManifestArchitect(claude)

    # Call with goal and task_number
    result = architect.create_manifest(goal="Create a new feature", task_number=42)

    assert isinstance(result, dict)
    assert "success" in result or "manifest_path" in result or "manifest_data" in result


def test_create_manifest_returns_dict_with_status():
    """Test create_manifest returns dict with status information."""
    claude = ClaudeWrapper(mock_mode=True)
    architect = ManifestArchitect(claude)

    result = architect.create_manifest(goal="Add user authentication", task_number=10)

    assert isinstance(result, dict)
    # Should have some indication of success/failure
    assert len(result) > 0


def test_create_manifest_response_structure():
    """Test create_manifest returns dict with expected fields."""
    claude = ClaudeWrapper(mock_mode=True)
    architect = ManifestArchitect(claude)

    result = architect.create_manifest(goal="Add user authentication", task_number=10)

    # Verify response has expected structure
    assert "success" in result
    assert "manifest_path" in result
    assert "manifest_data" in result
    assert "error" in result


def test_create_manifest_generates_correct_path():
    """Test create_manifest generates correctly formatted manifest path."""
    claude = ClaudeWrapper(mock_mode=True)
    architect = ManifestArchitect(claude)

    result = architect.create_manifest(goal="Create new feature", task_number=42)

    # When success is False (due to mock returning non-JSON),
    # manifest_path should be None or the expected path with descriptive slug
    if result["success"]:
        assert (
            result["manifest_path"]
            == "manifests/task-042-create-new-feature.manifest.json"
        )


def test_create_manifest_handles_invalid_json():
    """Test create_manifest handles invalid JSON from Claude gracefully."""
    claude = ClaudeWrapper(mock_mode=True)
    architect = ManifestArchitect(claude)

    result = architect.create_manifest(
        goal="Test invalid JSON handling", task_number=99
    )

    # Mock returns non-JSON string, should handle gracefully
    assert isinstance(result, dict)
    # Should have error information when JSON parsing fails
    if not result["success"]:
        assert result["error"] is not None
        assert "parse" in result["error"].lower() or result["error"] != ""


def test_execute_method_inherited_from_base():
    """Test execute method is available from BaseAgent."""
    claude = ClaudeWrapper(mock_mode=True)
    architect = ManifestArchitect(claude)

    result = architect.execute()

    assert isinstance(result, dict)
